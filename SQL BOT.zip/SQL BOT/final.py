from flask import Flask, render_template, jsonify, request
import json
import os
import pandas as pd
from sqlalchemy import create_engine
import re
import time
import google.generativeai as genai
from dotenv import load_dotenv
from langchain.prompts import PromptTemplate

app = Flask(__name__)
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

DATA_FILE = 'data.json'
schema_cache = {}

# === DB CONFIG ===
DRIVER = "ODBC Driver 17 for SQL Server"
SERVER = "LTIN490608\\MSSQLSERVER22"
DATABASE = "FinanceDB"
connection_string = f"mssql+pyodbc://{SERVER}/{DATABASE}?trusted_connection=yes&driver={DRIVER}"
engine = create_engine(connection_string)

# === Utility ===
def read_json():
    return json.load(open(DATA_FILE)) if os.path.exists(DATA_FILE) else {"content": ""}

def write_json(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

# === Schema Caching ===
def get_database_schema_cached(engine):
    if "schema" in schema_cache:
        return schema_cache["schema"]
    query = """
    SELECT TABLE_NAME, COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME IN (
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE = 'BASE TABLE'
    )
    """
    df = pd.read_sql(query, engine)
    schema = {}
    for table, group in df.groupby('TABLE_NAME'):
        schema[table] = group['COLUMN_NAME'].tolist()
    schema_cache["schema"] = schema
    return schema

# === Prompt Setup ===
def generate_prompt_template(schema):
    schema_details = ""
    for table, columns in schema.items():
        schema_details += f"Table Name: {table}\n" + "\n".join(columns) + "\n\n"
    relationships = """
Relationships:
- Customers.Account_Number = Assets.Account_Number
- Customers.Account_Number = Addresses.Account_Number
- Customers.Account_Number = Scores.Account_Number
- Customers.Account_Number = Amount_Details.Account_Number
"""
    instructions = """
Instructions:
- Output only SQL
- Use LEFT JOIN when enriching from base table
- Use aliases when needed
- Avoid extra joins
- WHERE clause for filters
- Use table and column names exactly from schema
"""
    return f"""You are a SQL assistant. {instructions}

Schema:
{schema_details}
{relationships}
Convert this question into a valid SQL query:
Question: {{question}}"""

def clean_sql_response(response):
    raw = response.text if hasattr(response, "text") else str(response)
    cleaned = re.sub(r"```sql|```", "", raw.strip(), flags=re.IGNORECASE)
    match = re.search(r"(SELECT .*?;)", cleaned, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else cleaned.strip()

# === SQL Validation ===
def levenshtein_distance(s1, s2):
    if len(s1) < len(s2): return levenshtein_distance(s2, s1)
    if len(s2) == 0: return len(s1)
    prev = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        curr = [i + 1]
        for j, c2 in enumerate(s2):
            insert = prev[j + 1] + 1
            delete = curr[j] + 1
            replace = prev[j] + (c1 != c2)
            curr.append(min(insert, delete, replace))
        prev = curr
    return prev[-1]

def find_closest_match_across_tables(table, column, schema):
    closest_table, closest_column, min_dist = None, None, float('inf')
    for tbl, cols in schema.items():
        for col in cols:
            dist = levenshtein_distance(f"{table}.{column}", f"{tbl}.{col}")
            if dist < min_dist:
                min_dist, closest_table, closest_column = dist, tbl, col
    return closest_table, closest_column

def validate_sql_query(query, schema):
    errors, suggestions = [], {}
    aliases = re.findall(r"\b(\w+)\.(\w+)\b", query)
    for alias, column in aliases:
        if alias.lower().startswith('t') and alias[1:].isdigit():
            continue
        found = any(column in cols for cols in schema.values())
        if not found:
            match_table, match_col = find_closest_match_across_tables(alias, column, schema)
            if match_table and match_col:
                original = f"{alias}.{column}"
                replacement = f"{match_table}.{match_col}"
                query = query.replace(original, replacement)
                suggestions[original] = replacement
            else:
                errors.append(f"Unknown column '{column}' in '{alias}'")
    return errors, suggestions, query

def execute_query(query, engine):
    return pd.read_sql(query, engine)

# # === Routes ===
# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/api/content', methods=['GET'])
# def get_content():
#     return jsonify(read_json())

# @app.route('/api/content', methods=['POST'])
# def update_content():
#     data = request.json
#     if 'content' in data:
#         write_json({'content': data['content']})
#         return jsonify({'status': 'success', 'content': data['content']})
#     return jsonify({'status': 'error', 'message': 'Missing content'}), 400

# @app.route('/api/query', methods=['POST'])
# def process_query():
#     data = request.get_json()
#     question = data.get('question', '').strip()
#     if not question:
#         return jsonify({'status': 'error', 'message': 'Missing question'}), 400

#     schema = get_database_schema_cached(engine)
#     prompt = PromptTemplate(input_variables=["question"], template=generate_prompt_template(schema))
#     formatted = prompt.format(question=question)

#     model = genai.GenerativeModel("gemini-2.0-flash")
#     try:
#         response = model.generate_content(formatted)
#         sql_query = clean_sql_response(response)
#     except Exception as e:
#         return jsonify({'status': 'error', 'message': str(e)})

#     if not sql_query:
#         return jsonify({'status': 'error', 'message': 'LLM returned no SQL'})

#     errors, suggestions, validated_query = validate_sql_query(sql_query, schema)

#     try:
#         df = execute_query(validated_query, engine)
#         return jsonify({
#             'status': 'success',
#             'query': validated_query,
#             'results': df.to_dict(orient='records'),
#             'suggestions': suggestions,
#             'errors': errors
#         })
#     except Exception as e:
#         return jsonify({'status': 'error', 'query': validated_query, 'message': str(e)})

# if __name__ == '__main__':
#     app.run(debug=True)
 