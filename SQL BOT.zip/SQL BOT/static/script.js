document.getElementById('send-btn').addEventListener('click', sendMessage);
document.getElementById('user-input').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const inputField = document.getElementById('user-input');
    const userInput = inputField.value.trim();
    if (!userInput) return;

    appendMessage('user', userInput);
    inputField.value = '';
    appendMessage('bot', 'Thinking... 🤔');

    fetch('/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: userInput })
    })
    .then(response => response.json())
    .then(data => {
        document.querySelector('.message.bot:last-child').remove();

        if (data.status === 'success') {
            const resultText = `🧠 SQL: ${data.query}\n📊 Result:\n${JSON.stringify(data.results, null, 2)}`;
            appendMessage('bot', resultText);
        } else {
            appendMessage('bot', `❌ Error: ${data.message}`);
        }
    })
    .catch(err => {
        document.querySelector('.message.bot:last-child').remove();
        appendMessage('bot', `⚠️ Network error: ${err}`);
    });
}

function appendMessage(sender, text) {
    const messagesDiv = document.getElementById('chat-messages');
    const messageEl = document.createElement('div');
    messageEl.classList.add('message', sender);
    messageEl.textContent = text;
    messagesDiv.appendChild(messageEl);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}
