import os
import json
import re
import pandas as pd
from sqlalchemy import create_engine
import google.generativeai as genai
from dotenv import load_dotenv
from langchain.prompts import PromptTemplate
import tkinter as tk
from tkinter import Entry, Button, scrolledtext
from PIL import Image, ImageTk
import requests

# === Load Environment & Gemini Configuration ===
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# === DB CONFIG ===
DRIVER = "ODBC Driver 17 for SQL Server"
SERVER = "LTIN490608\\MSSQLSERVER22"
DATABASE = "FinanceDB"
connection_string = f"mssql+pyodbc://{SERVER}/{DATABASE}?trusted_connection=yes&driver={DRIVER}"
engine = create_engine(connection_string)

schema_cache = {}

# === Schema Caching ===
def get_database_schema_cached(engine):
    if "schema" in schema_cache:
        return schema_cache["schema"]
    query = """
    SELECT TABLE_NAME, COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME IN (
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE = 'BASE TABLE'
    )
    """
    df = pd.read_sql(query, engine)
    schema = {}
    for table, group in df.groupby('TABLE_NAME'):
        schema[table] = group['COLUMN_NAME'].tolist()
    schema_cache["schema"] = schema
    return schema

# === Prompt Template Setup ===
def generate_prompt_template(schema):
    schema_details = ""
    for table, columns in schema.items():
        schema_details += f"Table Name: {table}\n" + "\n".join(columns) + "\n\n"
    relationships = """
Relationships:
- Customers.Account_Number = Assets.Account_Number
- Customers.Account_Number = Addresses.Account_Number
- Customers.Account_Number = Scores.Account_Number
- Customers.Account_Number = Amount_Details.Account_Number
"""
    instructions = """
Instructions:
- Output only SQL
- Use LEFT JOIN when enriching from base table
- Use aliases when needed
- Avoid extra joins
- WHERE clause for filters
- Use table and column names exactly from schema
"""
    return f"""You are a SQL assistant. {instructions}

Schema:
{schema_details}
{relationships}
Convert this question into a valid SQL query:
Question: {{question}}"""

def clean_sql_response(response):
    raw = response.text if hasattr(response, "text") else str(response)
    cleaned = re.sub(r"```sql|```", "", raw.strip(), flags=re.IGNORECASE)
    match = re.search(r"(SELECT .*?;)", cleaned, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else cleaned.strip()

# === SQL Validation & Auto-Correction ===
def levenshtein_distance(s1, s2):
    if len(s1) < len(s2): return levenshtein_distance(s2, s1)
    if len(s2) == 0: return len(s1)
    prev = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        curr = [i + 1]
        for j, c2 in enumerate(s2):
            insert = prev[j + 1] + 1
            delete = curr[j] + 1
            replace = prev[j] + (c1 != c2)
            curr.append(min(insert, delete, replace))
        prev = curr
    return prev[-1]

def find_closest_match_across_tables(table, column, schema):
    closest_table, closest_column, min_dist = None, None, float('inf')
    for tbl, cols in schema.items():
        for col in cols:
            dist = levenshtein_distance(f"{table}.{column}", f"{tbl}.{col}")
            if dist < min_dist:
                min_dist, closest_table, closest_column = dist, tbl, col
    return closest_table, closest_column

def validate_sql_query(query, schema):
    errors, suggestions = [], {}
    aliases = re.findall(r"\b(\w+)\.(\w+)\b", query)
    for alias, column in aliases:
        found = any(column in cols for cols in schema.values())
        if not found:
            match_table, match_col = find_closest_match_across_tables(alias, column, schema)
            if match_table and match_col:
                original = f"{alias}.{column}"
                replacement = f"{match_table}.{match_col}"
                query = query.replace(original, replacement)
                suggestions[original] = replacement
            else:
                errors.append(f"Unknown column '{column}' in '{alias}'")
    return errors, suggestions, query

def execute_query(query, engine):
    return pd.read_sql(query, engine)

# === GUI Logic ===
def ask_bot():
    question = entry.get()
    if not question.strip():
        return

    schema = get_database_schema_cached(engine)
    prompt = PromptTemplate(input_variables=["question"], template=generate_prompt_template(schema))
    formatted = prompt.format(question=question)

    model = genai.GenerativeModel("gemini-2.0-flash")
    try:
        response = model.generate_content(formatted)
        sql_query = clean_sql_response(response)
    except Exception as e:
        sql_query = ""
        display = f"Model Error: {e}"

    if not sql_query:
        display = "Error: LLM returned no SQL"
    else:
        errors, suggestions, validated_query = validate_sql_query(sql_query, schema)
        try:
            df = execute_query(validated_query, engine)
            display = f"SQL Query:\n{validated_query}\n\nResults:\n{df.to_dict(orient='records')}\n\nSuggestions:\n{suggestions}"
        except Exception as e:
            display = f"Execution Error: {e}\n\nQuery:\n{validated_query}"

    output.config(state='normal')
    output.delete("1.0", 'end')
    output.insert('end', display)
    output.config(state='disabled')

# === GUI Setup ===
window = tk.Tk()
window.title("SQL Query Generator")
window.geometry("900x600")
window.configure(bg="#1e1e1e")

modern_font_large = ('Inter', 15, 'bold')
modern_font_regular = ('Inter', 12)

# Header with Logo & Title
header = tk.Frame(window, bg="#1e1e1e")
header.pack(fill='x', pady=(5, 5))

logo_image = Image.open(r"C:\Users\2151155\Downloads\EditContent\EditContent\EditContent\honda.png")
logo_resized = logo_image.resize((100, 100))
logo = ImageTk.PhotoImage(logo_resized)

logo_label = tk.Label(header, image=logo, bg="#1e1e1e")
logo_label.image = logo
logo_label.pack(side='left', padx=(4, 5))

title_frame = tk.Frame(header, bg="#1e1e1e")
title_frame.pack(side='right', padx=4)

title_honda = tk.Label(title_frame, text="HONDA", font=('Inter', 18, 'bold'), bg="#1e1e1e", fg="#8B0000")
title_honda.pack(anchor='w')

title_tagline = tk.Label(title_frame, text="The Power of Dreams", font=('Inter', 12), bg="#1e1e1e", fg="#ffffff")
title_tagline.pack(anchor='w')

label = tk.Label(window, text="Please type your question here:",
                 font=modern_font_regular, bg="#1e1e1e", fg="#ffffff")
label.pack(pady=(10, 5), padx=20, anchor='w')

entry = Entry(window, font=modern_font_regular, bg="#ffffff", fg="#000000",
              relief='flat', bd=3, justify='left')
entry.pack(pady=(5, 15), padx=15, ipady=5, fill='x')

ask_button = Button(window, text="Generate", command=ask_bot,
                    font=modern_font_regular, bg="#007acc", fg="#fff",
                    activebackground="#005999", bd=0, padx=16, pady=8)
ask_button.pack(pady=(0, 15))

output = scrolledtext.ScrolledText(window, wrap='word', font=('Inter', 11),
                                   bg="#ffffff", fg="#333333", relief='solid', bd=2)
output.pack(padx=20, pady=10, fill='both', expand=True)

window.mainloop()
